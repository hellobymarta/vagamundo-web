// Los destinos, como los plantea NUBA: cada uno es una ficha con su
// continente, su fotografía y su entradilla, y tiene su propia página.
//
// El modelo de la API solo guarda un campo `destino` de texto libre
// («Costa amalfitana, Italia»), así que aquí está la tabla que lo traduce
// a un destino de verdad, igual que hacemos con las siluetas de los mapas.

import { FOTOS } from '@/config/constantes'
import { contienePalabra } from '@/formato'

export const DESTINOS = [
  {
    id: 'italia',
    nombre: 'Italia',
    continente: 'Europa',
    foto: FOTOS.PORTADA,
    fotoAlt: 'Positano al atardecer sobre el mar',
    titular: 'El país al que siempre volvemos',
    entradilla:
      'Empezamos aquí, y aquí seguimos. La costa amalfitana en mayo y el tacón de la bota en septiembre, cuando el sur vuelve a ser de los del sur.',
    pistas: ['italia', 'amalfi', 'amalfitana', 'apulia', 'positano', 'matera', 'bari', 'atrani', 'ravello'],
  },
  {
    id: 'grecia',
    nombre: 'Grecia',
    continente: 'Europa',
    foto: FOTOS.GRECIA,
    fotoAlt: 'Casas blancas sobre las rocas en Mikonos',
    titular: 'Primero las piedras, después el mar',
    entradilla:
      'Micenas, Delfos y Meteora entre semana, con las excavaciones casi vacías, y las Cícladas al final, cuando ya te has ganado el baño.',
    pistas: ['grecia', 'santorini', 'atenas', 'mikonos', 'cicladas', 'creta'],
  },
  {
    id: 'jordania',
    nombre: 'Jordania',
    continente: 'Oriente Medio',
    foto: FOTOS.JORDANIA,
    fotoAlt: 'Arco de roca en el desierto de Wadi Rum',
    titular: 'Un país entero en ocho días',
    entradilla:
      'Cabe en una semana y no se parece a nada: una ciudad romana, otra tallada en la roca, dos noches de desierto y un mar en el que no te hundes.',
    pistas: ['jordania', 'petra', 'wadi rum', 'amman', 'aqaba'],
  },
  {
    id: 'namibia',
    nombre: 'Namibia',
    continente: 'África',
    foto: FOTOS.NAMIBIA,
    fotoAlt: 'El arco de granito del Spitzkoppe al atardecer',
    titular: 'Donde el desierto llega hasta el mar',
    entradilla:
      'Tres millones de personas en un país vez y media más grande que España. Se conduce durante horas sin ver a nadie, y eso no es un inconveniente del viaje: es el viaje.',

    // La historia del sitio, para la ficha del viaje. Tres párrafos: qué es,
    // por qué es así y qué se siente estando allí.
    historia: [
      'Namibia es el segundo país menos densamente poblado del mundo, después de Mongolia, y el menos poblado de todos los que tienen costa: tres millones de habitantes repartidos en 825.000 kilómetros cuadrados, algo menos de cuatro personas por kilómetro. Eso, sobre el terreno, significa carreteras de grava rectas durante dos horas sin un solo coche de frente.',
      'El Namib, que le da nombre al país, es el desierto más antiguo de la Tierra. En Deadvlei quedan en pie las acacias de un bosque que se secó hace unos novecientos años, cuando las dunas cortaron el paso del río que lo alimentaba. No se han podrido: no hay humedad suficiente para que la madera se descomponga. Siguen ahí, negras sobre el barro blanco, con una duna naranja de más de trescientos metros detrás.',
      'Y luego está la fauna, que aquí no vive en una reserva vallada sino en un país entero. En Etosha los animales van al agua porque no hay otra, así que no se les busca: se aparca junto a una charca al amanecer y se espera. Los elefantes de Namibia son los más grandes de África y llegan cubiertos del polvo blanco de la llanura salada.',
    ],

    // Datos de cabecera, los de verdad, verificados.
    datos: [
      { etiqueta: 'Capital', valor: 'Windhoek' },
      { etiqueta: 'Idioma oficial', valor: 'Inglés' },
      { etiqueta: 'Moneda', valor: 'Dólar namibio' },
      { etiqueta: 'Cuándo ir', valor: 'De mayo a octubre' },
    ],

    // La galería del destino. Cada foto con su rótulo y su pie: así el
    // bloque cuenta algo y no es solo decoración.
    galeria: [
      {
        id: 'deadvlei',
        foto: FOTOS.NAMIBIA_DESIERTO,
        alt: 'Acacias secas sobre el barro blanco de Deadvlei, con una duna naranja detrás',
        rotulo: 'Deadvlei',
        pie: 'Las acacias llevan novecientos años muertas y siguen en pie: no hay humedad para que se podran.',
      },
      {
        id: 'etosha',
        foto: FOTOS.NAMIBIA_FAUNA,
        alt: 'Una fila de elefantes caminando de espaldas en la llanura de Etosha',
        rotulo: 'Etosha',
        pie: 'Aquí no se buscan los animales. Se aparca junto a una charca al amanecer y se espera.',
      },
      {
        id: 'carretera',
        foto: FOTOS.NAMIBIA_SAFARI,
        alt: 'Cebras cruzando una carretera de grava bajo un cielo de tormenta',
        rotulo: 'La C38',
        pie: 'La carretera es de grava y la prioridad no es tuya. Se para el motor y se deja pasar.',
      },
      {
        id: 'damaraland',
        foto: FOTOS.NAMIBIA_FLORA,
        alt: 'Dunas rojas con hierba dorada y montañas al fondo, en Damaraland',
        rotulo: 'Damaraland',
        pie: 'Después de las lluvias de febrero la arena roja se llena de hierba amarilla. Dura seis semanas.',
      },
      {
        id: 'spitzkoppe',
        foto: FOTOS.NAMIBIA,
        alt: 'El arco de granito del Spitzkoppe al atardecer',
        rotulo: 'Spitzkoppe',
        pie: 'El granito de estas piedras tiene más de setecientos millones de años. Se duerme debajo.',
      },
    ],

    pistas: [
      'namibia',
      'etosha',
      'sossusvlei',
      'deadvlei',
      'windhoek',
      'kalahari',
      'damaraland',
      'spitzkoppe',
      'namib',
    ],
  },
  {
    id: 'brasil',
    nombre: 'Brasil',
    continente: 'América',
    foto: FOTOS.BRASIL,
    fotoAlt: 'Lagunas de agua de lluvia entre las dunas de los Lençóis',
    titular: 'El nordeste, no las postales',
    entradilla:
      'Ni Río ni el Cristo. Mil kilómetros de dunas, lagunas que solo existen medio año y pueblos de pescadores a los que se llega en 4x4.',
    pistas: ['brasil', 'brazil', 'lencois', 'lençóis', 'jericoacoara', 'fortaleza', 'bahia'],
  },
  {
    id: 'guatemala',
    nombre: 'Guatemala',
    continente: 'América',
    foto: FOTOS.GUATEMALA,
    fotoAlt: 'El templo del Gran Jaguar en Tikal',
    titular: 'Tres volcanes desde el desayuno',
    entradilla:
      'Un lago con doce pueblos alrededor, el mercado más ruidoso de Centroamérica y una ciudad maya que la selva se tragó durante mil años.',
    pistas: ['guatemala', 'tikal', 'antigua', 'atitlan', 'atitlán', 'chichicastenango'],
  },
  {
    id: 'india',
    nombre: 'India',
    continente: 'Asia',
    foto: FOTOS.INDIA,
    fotoAlt: 'El Taj Mahal reflejado en el agua al amanecer',
    titular: 'De Delhi al Ganges',
    entradilla:
      'El norte, en el orden que aguanta el cuerpo: las ciudades primero, el mármol de Agra a las seis de la mañana y Benarés al final.',
    pistas: ['india', 'delhi', 'jaipur', 'agra', 'benares', 'varanasi', 'rajastan'],
  },
  {
    id: 'uzbekistan',
    nombre: 'Uzbekistán',
    continente: 'Asia',
    foto: FOTOS.UZBEKISTAN,
    fotoAlt: 'La plaza del Registán en Samarcanda',
    titular: 'La Ruta de la Seda, en tren',
    entradilla:
      'Samarcanda, Bujará y Jiva. Cúpulas de azulejo turquesa, melón en cada comida y trenes de alta velocidad entre oasis, que nadie se espera.',
    pistas: ['uzbekistan', 'uzbekistán', 'samarcanda', 'bujara', 'bukhara', 'tashkent', 'jiva'],
  },
  {
    id: 'costarica',
    nombre: 'Costa Rica',
    continente: 'América',
    foto: FOTOS.COSTARICA,
    fotoAlt: 'Costa del Pacífico en Costa Rica',
    titular: 'En preparación para 2027',
    entradilla:
      'Estamos recorriéndolo ahora: el Arenal, Monteverde y la costa del Pacífico. Abrimos plazas cuando lo hayamos hecho enteras nosotras.',
    pistas: ['costa rica', 'arenal', 'monteverde', 'tortuguero'],
  },
  {
    id: 'bolivia',
    nombre: 'Bolivia',
    continente: 'América',
    foto: FOTOS.SALAR,
    fotoAlt: 'Un salar al atardecer',
    titular: 'En preparación para 2027',
    entradilla:
      'El salar de Uyuni sin caravana de todoterrenos, que es más difícil de lo que parece. Estamos buscando la manera.',
    pistas: ['bolivia', 'uyuni', 'la paz'],
  },
]

// De un texto libre («Nordeste de Brasil») al destino que le toca.
// Compara por palabras completas, no por trozos: «Polinesia Francesa» no
// puede acabar clasificada como Francia.
export function buscarDestino(texto = '') {
  return (
    DESTINOS.find(({ pistas }) => pistas.some((pista) => contienePalabra(texto, pista))) || null
  )
}

// El nombre corto de un destino, para los títulos grandes.
//
// Utópica no pone en su hero el nombre del viaje, sino el del sitio: «Chile»,
// «Omán», «Maldivas». Dos palabras como mucho. Aquí hacemos lo mismo:
//   «Costa amalfitana, Italia» -> «Italia»   (lo dice la tabla de destinos)
//   «Kioto, Japón»             -> «Japón»
//   «Polinesia Francesa»       -> «Polinesia Francesa»  (se queda tal cual)
export function nombreCorto(texto = '') {
  const encontrado = buscarDestino(texto)
  if (encontrado) return encontrado.nombre

  // Si no está en la tabla, nos quedamos con lo que va después de la última
  // coma, que en un «Ciudad, País» es justo el país.
  const trozos = texto.split(',')
  return trozos[trozos.length - 1].trim() || texto
}

// Todos los viajes que caen en un destino.
export function viajesDeDestino(viajes, id) {
  return viajes.filter(({ destino }) => buscarDestino(destino)?.id === id)
}

// La fotografía que le corresponde a un destino, para no acabar poniendo
// una foto de Amalfi en un viaje a Namibia.
export function fotoDeDestino(texto, porDefecto) {
  return buscarDestino(texto)?.foto || porDefecto
}

// Los continentes en el orden de NUBA, con sus destinos dentro.
export const CONTINENTES_CON_DESTINOS = ['Europa', 'África', 'Oriente Medio', 'Asia', 'América']
  .map((nombre) => ({
    nombre,
    destinos: DESTINOS.filter((destino) => destino.continente === nombre),
  }))
  .filter(({ destinos }) => destinos.length > 0)
